---
name: Human-Centric Artisanal System
colors:
  surface: '#fdf8f6'
  surface-dim: '#ddd9d7'
  surface-bright: '#fdf8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3f1'
  surface-container: '#f1edeb'
  surface-container-high: '#ece7e5'
  surface-container-highest: '#e6e2e0'
  on-surface: '#1c1b1a'
  on-surface-variant: '#53433e'
  inverse-surface: '#31302f'
  inverse-on-surface: '#f4f0ee'
  outline: '#86736d'
  outline-variant: '#d9c2ba'
  surface-tint: '#8f4c34'
  primary: '#6f331d'
  on-primary: '#ffffff'
  primary-container: '#8c4a32'
  on-primary-container: '#ffc9b7'
  inverse-primary: '#ffb59c'
  secondary: '#865132'
  on-secondary: '#ffffff'
  secondary-container: '#ffba93'
  on-secondary-container: '#7a4829'
  tertiary: '#49443d'
  on-tertiary: '#ffffff'
  tertiary-container: '#615b54'
  on-tertiary-container: '#ddd3ca'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59c'
  on-primary-fixed: '#380c00'
  on-primary-fixed-variant: '#72351f'
  secondary-fixed: '#ffdbc9'
  secondary-fixed-dim: '#fdb790'
  on-secondary-fixed: '#331200'
  on-secondary-fixed-variant: '#6a3b1d'
  tertiary-fixed: '#ebe1d8'
  tertiary-fixed-dim: '#cec5bc'
  on-tertiary-fixed: '#1f1b16'
  on-tertiary-fixed-variant: '#4c463f'
  background: '#fdf8f6'
  on-background: '#1c1b1a'
  surface-variant: '#e6e2e0'
typography:
  display:
    fontFamily: Literata
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Literata
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Literata
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Literata
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style

This design system rejects the sterile, high-gloss aesthetic of traditional tech in favor of a "Human-Centric Artisanal" style. It draws inspiration from organic textures, traditional medium art, and the tactile nature of physical paper and pigment. 

The aesthetic is characterized by:
- **Organic Minimalism:** Using generous whitespace (or "paper-space") to let content breathe, avoiding cluttered dashboards.
- **Tactile Modernism:** Incorporating subtle grain, ink-bleed effects, and gouache-inspired brushwork to soften digital edges.
- **Artisanal Sophistication:** A focus on high-quality typography and a warm, grounded color palette that feels like a curated studio rather than a command center.
- **Human Connection:** The interface should feel like it was crafted by hand, evoking an emotional response of calm, focus, and reliability.

## Colors

The palette is rooted in the earth, utilizing pigments found in nature to ground the digital experience.

- **Primary (Terracotta/Clay):** Used for primary actions and key brand moments. It conveys warmth and grounded energy.
- **Secondary (Soft Sand):** Used for accents, secondary buttons, and highlighted states.
- **Background (Cream/Paper):** The foundation of the UI is `#F9F7F2` (Cream), mimicking high-quality art paper. 
- **Surface (Clay/Pastel):** Use `tertiary_color_hex` for cards and containers to create a soft, layered depth.
- **Text (Charcoal):** Use `neutral_color_hex` for all primary text to ensure high legibility while avoiding the harshness of pure black.

## Typography

The typography strategy pairs a literary, bookish serif with a friendly, contemporary sans-serif.

- **Literata (Headings):** Selected for its scholarly yet warm character. It should be used for all editorial headlines and page titles.
- **Be Vietnam Pro (Body & UI):** Provides a clean, highly readable contrast to the serif headings. Its open apertures keep the interface feeling modern and approachable.
- **Stylistic Note:** Use slightly tighter letter-spacing for large display headings to mimic traditional typesetting.

## Layout & Spacing

The layout philosophy follows a **Fluid Grid** with generous, intentional breathing room.

- **Grid:** Use a 12-column grid for desktop with 24px gutters. For mobile, shift to a 4-column grid with 16px margins.
- **Rhythm:** Spacing should feel "loose" rather than "tight." Use `lg` (48px) and `xl` (80px) vertical spacing between major sections to emphasize the minimalist, artisanal feel.
- **Alignment:** While the grid is structured, allow for "optical" alignment where elements like icons or hand-drawn strokes may slightly break the grid to feel more organic.

## Elevation & Depth

This design system avoids heavy shadows and synthetic glows. Instead, it uses:

- **Tonal Layering:** Depth is communicated by placing darker cream or terracotta surfaces on top of lighter cream backgrounds.
- **Ink Outlines:** Use subtle, slightly irregular 1px strokes in a "diluted ink" color (Charcoal at 15% opacity) to define boundaries.
- **Texture Overlays:** Apply a very fine noise or grain texture across the entire UI to simulate the surface of paper.
- **Soft Shadows:** If elevation is required (e.g., a floating menu), use a "tinted ambient shadow"—a very wide, low-opacity shadow colored with the primary terracotta hue rather than gray.

## Shapes

The shape language is "Softly Geometric."

- **Corner Radii:** We use `0.5rem` (8px) as the standard radius for cards and input fields. This provides a gentle silhouette without appearing overly "bubbly" or juvenile.
- **Organic Accents:** Incorporate non-geometric shapes for decorative elements, such as hand-painted "blobs" for background accents or "ink splash" indicators for active states.
- **Interactive Elements:** Use pill-shapes for buttons and chips to distinguish them from structural containers.

## Components

### Buttons
- **Primary:** Solid terracotta (`#8C4A32`) with cream text. Shape: Pill-shaped. Apply a subtle "gouache" inner glow.
- **Secondary:** Outlined with a 1.5px ink-stroke. Text in terracotta.
- **Tertiary:** Text-only with a terracotta underline that looks like a hand-drawn stroke.

### Input Fields
- **Styling:** Soft beige background with an "ink-bleed" bottom border. When focused, the border transitions to a terracotta hand-drawn line.
- **Typography:** Labels use `label-md` in Charcoal.

### Cards
- **Styling:** Use a slightly darker cream background than the main page. No shadows; instead, use a 1px soft clay border.
- **Content:** Header titles in Literata (`headline-md`).

### Selection Controls
- **Checkboxes/Radios:** Should look slightly "sketched." When selected, the fill should have a subtle watercolor-like transparency (not a solid flat color).

### Hand-Drawn Elements
- **Dividers:** Use horizontal lines that look like quick charcoal strokes—tapering at the ends rather than perfectly rectangular.
- **Icons:** Use monoline icons with slightly softened terminals (rounded ends) to match the hand-crafted aesthetic.